# vpsfreescripts
Files for scripts of vpsfree

Install minecraft Ipv6 only vps:

- bash <(curl -s https://raw.githubusercontent.com/dxomg/vpsfreescripts/main/vpsfreescripts/minecraftscript/install.sh)
